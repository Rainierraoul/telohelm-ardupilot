"""Running model-written code inside a contained process (architecture section 6, macOS route).

One call runs one function from untrusted source in a fresh process. The boundary is:
- a macOS sandbox profile that denies everything by default. It allows only executing the Python
  interpreter, reading the interpreter's own installation and the system libraries, and reading the
  root directory's listing, which Python needs at start-up. No other file can be read, listed, stat-ed
  or written, and network, process creation, fork and reading system values (sysctl) are denied. Denying
  sysctl closes a gap found in testing: with it allowed, sandboxed code could list every process and read
  another process's command line;
- an empty environment, no inherited file descriptors besides the stdin and stdout pipes, and the
  root directory as the working directory;
- limits on processor time, wall-clock time, open files, file size and the size of the reply;
- a memory limit enforced from outside: macOS refuses to lower a process's memory limits, so the parent
  reads the child's resident memory every 50 ms, through libproc, and kills it above MEMORY_LIMIT_MB. An allocation can
  overshoot by what the child touches between two readings.

The code receives one JSON input and returns one JSON value. It never sees a file path, the world, the
monitor or the logs. Whether the boundary holds is shown by the containment tests in
tests/test_sandbox.py, not by this description.

The Linux route (TURN 117, for the cluster; tests in tests/test_sandbox_linux.py) builds the same boundary from
unprivileged kernel features, with no change to the machine and no special rights:
- each call starts in new user, process-ID, mount, IPC and host-name namespaces (unshare), inside one network
  namespace that the calling process keeps for all its calls (the route of this build, LINUX_ROUTE below). That
  network namespace has only a loopback that is down, so there is no network;
- inside them a trusted setup script mounts an empty in-memory root, binds into it, read-only, only the Python
  installation, the system libraries and /dev/null and /dev/urandom, and then makes the root read-only too. No other
  file of the machine exists there; /proc is not mounted, so no other process can be seen;
- the process then changes into that root and starts Python, whose first lines (LINUX_DROP, trusted) drop every
  privilege before the runner reads any model-written code: an empty capability bounding set, no capabilities of any
  kind, root in the namespace given none back on exec (the noroot securebits, locked), and no new privileges ever. So
  it cannot undo the mounts. If any step fails, or a capability is still held afterwards, the process exits before
  the runner starts. setpriv cannot do this inside the root, because its library reads /proc, which is not there;
- limits on processor time, open files and file size as on macOS; at most one process (RLIMIT_NPROC, set in the same
  first lines), so it cannot start another; and an address-space limit that makes an oversized allocation fail
  inside the process, reported as status 'memory'. macOS refuses to set that limit, which is why it polls memory
  from outside.
The route is available only where unshare, chroot, nsenter and cat exist and unprivileged user namespaces are enabled;
otherwise SandboxUnavailable is raised, as before.

This is the Paper 3 build of the module (notes/TAKEOVER-20261111.md, round five, rulings 17 and 18), made from the
Paper 2 wheel's file by a patch kept in paper3/protocol/wheel3/. It changes the Linux route only, in two ways.
- One network namespace for each driver process. Making a network namespace for each call made some calls wait 100 ms
  to several seconds on the cluster's nodes. A holder process (`unshare --user --map-root-user --net cat`) keeps one
  network namespace for this process, and each call joins it with nsenter before it makes its own user, process-ID,
  mount, IPC and host-name namespaces. A namespace that a stopped call may have touched is never joined again: the
  holder is then marked spent and replaced. A dead or changed holder raises RouteError; nothing falls back to a
  network namespace for each call.
- A new, empty session keyring for each call, joined in the child before it starts (_limits). A batch job's session
  keyring belongs to the batch system and is shared by every job step on the node, so without this a call could find
  and read keys there. The first lines of LINUX_DROP then check that the keyring is empty, and a seccomp filter makes
  add_key, request_key and keyctl fail, so that a call cannot even test a guessed key number. The same filter makes
  socket, socketpair and io_uring_setup fail, so that a call can create nothing in the network namespace it shares
  with the calls after it (an IPv6 flow label, for one, outlives the call that made it).
"""
from __future__ import annotations

import ctypes
import errno
import json
import os
import platform
import resource
import select
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

CPU_SECONDS = 2
WALL_SECONDS = 5.0
MAX_REPLY_BYTES = 256_000
MAX_OPEN_FILES = 32
MEMORY_LIMIT_MB = 512
MEMORY_POLL_S = 0.05

RUNNER = r'''
import json, sys

class Ctx:
    """Read-only record with attribute access only (backlog note B7)."""
    __slots__ = ("_d",)
    def __init__(self, d):
        object.__setattr__(self, "_d", d)
    def __getattr__(self, k):
        d = object.__getattribute__(self, "_d")
        if k in d:
            return wrap(d[k])
        raise AttributeError(k)
    def __setattr__(self, k, v):
        raise AttributeError("context is read-only")

def wrap(v):
    if isinstance(v, dict):
        return Ctx(v)
    if isinstance(v, list):
        return tuple(wrap(x) for x in v)
    return v

msg = json.loads(sys.stdin.read())
ns = {"__name__": "procedure"}
try:
    exec(compile(msg["code"], "<procedure>", "exec"), ns)
    fn = ns[msg["entry"]]
    args = [wrap(a) for a in msg["input"]] if msg["wrap"] else [msg["input"]]
    out = {"ok": True, "result": fn(*args)}
except BaseException as e:
    out = {"ok": False, "error": type(e).__name__ + ": " + str(e)[:500]}
try:
    text = json.dumps(out, allow_nan=False)
except (TypeError, ValueError) as e:
    text = json.dumps({"ok": False, "error": "result is not JSON: " + str(e)[:200]})
sys.stdout.write(text)
'''


# The broker channel (TURN 56; paper2/notes/BROKER-CONTRACT.md). Every message in either direction is one frame:
# a kind byte, ten ASCII digits giving the body's length, then the body. The parent sends M (the call) and A
# (each broker reply); the child sends R (each broker request) and F (its final result). predict(args) is the
# only name the procedure gets for it. Anything else on the pipe is a protocol violation and ends the call.
FRAME_HEAD = 11
RUNNER_BROKER = r"""
import json, sys
_in, _out = sys.stdin.buffer, sys.stdout.buffer

def _frame(kind):
    head = _in.read(11)
    if len(head) != 11 or head[:1] != kind or not head[1:].isdigit():
        raise SystemExit(3)
    n = int(head[1:])
    body = _in.read(n)
    if len(body) != n:
        raise SystemExit(3)
    return body

def _send(kind, body):
    _out.write(kind + b"%010d" % len(body) + body)
    _out.flush()

class Ctx:
    __slots__ = ("_d",)
    def __init__(self, d):
        object.__setattr__(self, "_d", d)
    def __getattr__(self, k):
        d = object.__getattribute__(self, "_d")
        if k in d:
            return wrap(d[k])
        raise AttributeError(k)
    def __setattr__(self, k, v):
        raise AttributeError("context is read-only")

def wrap(v):
    if isinstance(v, dict):
        return Ctx(v)
    if isinstance(v, list):
        return tuple(wrap(x) for x in v)
    return v

def predict(args):
    _send(b"R", json.dumps({"capability": "predict", "args": args}, allow_nan=False).encode())
    return json.loads(_frame(b"A"))

msg = json.loads(_frame(b"M"))
ns = {"__name__": "procedure", "predict": predict}
try:
    exec(compile(msg["code"], "<procedure>", "exec"), ns)
    fn = ns[msg["entry"]]
    args = [wrap(a) for a in msg["input"]] if msg["wrap"] else [msg["input"]]
    out = {"ok": True, "result": fn(*args)}
except BaseException as e:
    out = {"ok": False, "error": type(e).__name__ + ": " + str(e)[:500]}
try:
    text = json.dumps(out, allow_nan=False)
except (TypeError, ValueError) as e:
    text = json.dumps({"ok": False, "error": "result is not JSON: " + str(e)[:200]})
_send(b"F", text.encode())
"""


class SandboxUnavailable(RuntimeError):
    """No tested containment route exists on this platform. Model-written code must not run."""


@dataclass(frozen=True)
class SandboxResult:
    status: str               # 'ok', 'error' (the code raised or returned non-JSON), 'timeout', 'memory', 'crashed', 'bad_reply'
    result: Any = None
    error: str | None = None
    wall_seconds: float = 0.0
    cpu_seconds: float | None = None   # None when not measured, never an unmeasured zero
    reply_bytes: int = 0
    broker_requests: int = 0           # requests the child sent over the broker channel


def interpreter() -> Path:
    """The framework Python binary itself; bin/python3.12 re-launches it, which the profile would refuse."""
    base = Path(os.path.realpath(sys.base_prefix))
    inner = base / "Resources" / "Python.app" / "Contents" / "MacOS" / "Python"
    return inner if inner.exists() else Path(os.path.realpath(sys.executable))


def _ancestors(path: Path) -> list[str]:
    return [str(p) for p in reversed(path.parents)]


def profile(python: Path) -> str:
    """The sandbox policy, deny by default."""
    base = Path(os.path.realpath(sys.base_prefix))
    install = base.parents[3] if len(base.parents) > 3 else base    # e.g. .../Cellar/python@3.12
    reads = [str(install), "/usr/lib", "/System"]
    if str(install).startswith("/opt/homebrew/"):
        reads.append("/opt/homebrew/opt")                           # Homebrew's links to shared libraries
    devices = ["/dev/null", "/dev/urandom", "/dev/random"]
    meta = sorted({a for r in reads for a in _ancestors(Path(r))} | {"/dev", "/private", "/var", "/etc", "/tmp"})
    q = lambda s: json.dumps(s)
    return "\n".join([
        "(version 1)",
        "(deny default)",
        f"(allow process-exec (literal {q(str(python))}))",
        "(allow file-read* (literal \"/\") " + " ".join(f"(subpath {q(r)})" for r in reads)
        + " (subpath \"/private/var/db/dyld\") " + " ".join(f"(literal {q(d)})" for d in devices) + ")",
        "(allow file-read-metadata " + " ".join(f"(literal {q(m)})" for m in meta)
        + " " + " ".join(f"(subpath {q(r)})" for r in reads) + " (subpath \"/private/var/db/dyld\") "
        + " ".join(f"(literal {q(d)})" for d in devices) + ")",
    ])


def _limits() -> None:
    resource.setrlimit(resource.RLIMIT_CPU, (CPU_SECONDS, CPU_SECONDS))
    resource.setrlimit(resource.RLIMIT_FSIZE, (0, 0))
    resource.setrlimit(resource.RLIMIT_NOFILE, (MAX_OPEN_FILES, MAX_OPEN_FILES))
    if sys.platform == "linux":            # Linux can limit address space; macOS refuses (see _watch_memory)
        limit = LINUX_ADDRESS_SPACE_MB * 1024**2
        resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
        _join_session_keyring()


class _RusageInfoV0(ctypes.Structure):
    _fields_ = [("ri_uuid", ctypes.c_uint8 * 16), ("ri_user_time", ctypes.c_uint64),
                ("ri_system_time", ctypes.c_uint64), ("ri_pkg_idle_wkups", ctypes.c_uint64),
                ("ri_interrupt_wkups", ctypes.c_uint64), ("ri_pageins", ctypes.c_uint64),
                ("ri_wired_size", ctypes.c_uint64), ("ri_resident_size", ctypes.c_uint64),
                ("ri_phys_footprint", ctypes.c_uint64), ("ri_proc_start_abstime", ctypes.c_uint64),
                ("ri_proc_exit_abstime", ctypes.c_uint64)]


_LIBPROC = ctypes.CDLL("/usr/lib/libproc.dylib") if sys.platform == "darwin" else None


def resident_mb(pid: int) -> float | None:
    """The process's resident memory in megabytes, None once it has gone. On macOS this reads libproc's
    proc_pid_rusage in the parent (about 1.6 µs; launching ps took about 4.7 ms and slowed every call)."""
    if _LIBPROC is not None:
        info = _RusageInfoV0()
        if _LIBPROC.proc_pid_rusage(pid, 0, ctypes.byref(info)) != 0:
            return None
        return info.ri_resident_size / 1024**2
    out = subprocess.run(["ps", "-o", "rss=", "-p", str(pid)], capture_output=True, text=True).stdout.strip()
    return int(out) / 1024 if out else None


def _watch_memory(proc: subprocess.Popen, limit_mb: float, flag: dict) -> None:
    while proc.poll() is None:
        mb = resident_mb(proc.pid)
        if mb is not None:
            flag["peak_mb"] = max(flag.get("peak_mb", 0.0), mb)
            if mb > limit_mb:
                flag["exceeded"] = True
                proc.kill()
                return
        time.sleep(MEMORY_POLL_S)


LINUX_ROUTE = "netns-per-process+keyring-per-call/2"
LINUX_TOOLS = ("unshare", "chroot", "nsenter", "cat")
# The sandbox starts every call with an empty environment. Popen then finds unshare and nsenter, and nsenter finds
# unshare, on the default path /bin:/usr/bin (os.defpath). chroot is run by sh, which has a wider default path of its
# own, and on the cluster's Ubuntu 22.04 chroot is /usr/sbin/chroot, so it is looked for where sh looks.
SH_DEFAULT_PATH = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
LINUX_TOOL_PATHS = {"chroot": SH_DEFAULT_PATH}
HOLDER_COMMAND = ["unshare", "--user", "--map-root-user", "--net", "cat"]
JOIN_WORDS = ["nsenter", "--target", "{holder}", "--user", "--net", "--preserve-credentials"]
CALL_NAMESPACES = ["unshare", "--user", "--map-root-user", "--pid", "--fork", "--kill-child", "--mount", "--ipc",
                   "--uts"]
# System call numbers of add_key, request_key and keyctl, and the audit machine code, for the two machines that have
# a Linux route. Any other machine has none.
KEY_CALLS = {"x86_64": (248, 249, 250, 0xC000003E), "aarch64": (217, 218, 219, 0xC00000B7)}
# socket, socketpair and io_uring_setup, which the filter refuses as well: a call must not be able to create anything
# in the network namespace that later calls share. io_uring can open a socket on newer kernels without the socket call.
NAMESPACE_CALLS = {"x86_64": (41, 53, 425), "aarch64": (198, 199, 425)}
KEYCTL_JOIN_SESSION_KEYRING = 1
HOLDER_READY_S = 5.0
SOCKET_TABLES = ("unix", "netlink", "packet", "tcp", "tcp6", "udp", "udp6", "udplite", "udplite6", "raw", "raw6",
                 "icmp", "icmp6", "ip6_flowlabel")
TRUSTED_CALL = "def decide(_):\n    return 1\n"
LINUX_ADDRESS_SPACE_MB = 1024          # the address-space limit; resident memory stays well below it
LINUX_ROOT = "/mnt"                    # where the empty root is mounted, inside the private mount namespace


def _linux_available() -> bool:
    if sys.platform != "linux" or not all(shutil.which(t, path=LINUX_TOOL_PATHS.get(t, os.defpath))
                                          for t in LINUX_TOOLS):
        return False
    flag = Path("/proc/sys/kernel/unprivileged_userns_clone")
    return not flag.exists() or flag.read_text().strip() != "0"


def available() -> bool:
    if sys.platform == "darwin":
        return shutil.which("sandbox-exec") is not None
    return _linux_available()


class RouteError(SandboxUnavailable):
    """The Linux route cannot be used as built: the holder is missing, has ended, has changed namespace, or the route
    cannot start. Nothing falls back to a network namespace for each call, so the flight stops."""


_LIBC = ctypes.CDLL(None, use_errno=True) if sys.platform == "linux" else None


def key_calls() -> tuple | None:
    """(add_key, request_key, keyctl, audit machine code) for this machine, or None where there is no Linux route."""
    return KEY_CALLS.get(platform.machine())


def _syscall(number: int, *args) -> int:
    """A system call through the C library: its result, or minus errno when it fails. An int argument is passed as a
    long and a bytes argument as a pointer to its text."""
    _LIBC.syscall.restype = ctypes.c_long
    converted = [ctypes.c_char_p(a) if isinstance(a, bytes) else ctypes.c_long(a) for a in args]
    result = _LIBC.syscall(ctypes.c_long(number), *converted)
    return -ctypes.get_errno() if result < 0 else result


_KEYRINGS_ABSENT = False    # set when the kernel has no keys (ENOSYS), so that the join may fail with ENOSYS


def _join_session_keyring() -> None:
    """Called in the child between fork and exec. keyctl(KEYCTL_JOIN_SESSION_KEYRING, NULL) gives the child and
    everything it starts a new, empty session keyring, so that it cannot reach the keyring a batch job inherits from
    the batch system. A failure raises, which makes Popen raise in the parent and the call is not made. The one
    exception is a kernel built without keys, where there is no keyring to reach."""
    calls = key_calls()
    if calls is None:
        raise OSError(f"no keyring system call numbers for the machine {platform.machine()!r}")
    result = _syscall(calls[2], KEYCTL_JOIN_SESSION_KEYRING, 0)
    if result < 0 and not (result == -errno.ENOSYS and _KEYRINGS_ABSENT):
        raise OSError(-result, "keyctl(KEYCTL_JOIN_SESSION_KEYRING) failed: " + os.strerror(-result))


def _ns(pid, kind: str) -> str:
    return os.readlink(f"/proc/{pid}/ns/{kind}")


def _socket_counts(pid: int) -> dict:
    """The number of lines in each socket table of the process's network namespace that exists. The driver can read
    them because the holder's user namespace belongs to the driver's user."""
    counts = {}
    for table in SOCKET_TABLES:
        try:
            with open(f"/proc/{pid}/net/{table}", "rb") as f:
                counts[table] = f.read().count(b"\n")
        except FileNotFoundError:
            continue
        except OSError as error:
            raise RouteError(f"the socket table {table} of the holder {pid} cannot be read: {error}") from error
    return counts


class Holder:
    """The process whose network namespace every call of one driver process joins."""

    def __init__(self):
        self.owner = os.getpid()     # the process that started it; no other process may use it
        self.baseline: dict = {}     # the socket tables' line counts when it was ready
        self.spent = None            # (call number, status, reason, table) once it must not be joined again
        self.proc = subprocess.Popen(HOLDER_COMMAND, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, env={}, cwd="/", close_fds=True)
        self.pid = self.proc.pid
        try:
            self.proc.stdin.write(b"ready\n")
            self.proc.stdin.flush()
            readable, _, _ = select.select([self.proc.stdout], [], [], HOLDER_READY_S)
            line = os.read(self.proc.stdout.fileno(), 64) if readable else b""
            if line != b"ready\n":
                self.close()
                raise RouteError(f"the holder did not answer within {HOLDER_READY_S} s: {line!r}; "
                                 f"it said {self.proc.stderr.read()[-500:]!r}")
            self.proc.stdout.close()
            self.proc.stderr.close()
            self.user_ns, self.net_ns = _ns(self.pid, "user"), _ns(self.pid, "net")
            if self.net_ns == _ns("self", "net") or self.user_ns == _ns("self", "user"):
                raise RouteError("the holder is not in namespaces of its own")
            with open(f"/proc/{self.pid}/uid_map") as f:
                uid_map = f.read().split()
            if uid_map[:3] != ["0", str(os.geteuid()), "1"]:
                raise RouteError(f"the holder maps users as {uid_map}, not 0 to {os.geteuid()}")
        except BaseException:
            self.close()
            raise

    def alive(self) -> bool:
        """True while the holder runs. WNOWAIT leaves an ended holder unreaped, so its number stays ours."""
        try:
            return os.waitid(os.P_PID, self.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT) is None
        except ChildProcessError:
            return False

    def check(self) -> None:
        if self.owner != os.getpid():
            raise RouteError(f"the holder {self.pid} was started by process {self.owner}, not by this process")
        if not self.alive():
            raise RouteError(f"the network namespace holder {self.pid} has ended")
        try:
            now = _ns(self.pid, "net")
        except OSError as error:
            raise RouteError(f"the holder {self.pid} cannot be read: {error}") from error
        if now != self.net_ns:
            raise RouteError(f"the holder {self.pid} is in {now}, not {self.net_ns}")

    def close(self) -> None:
        """End the holder: closing its standard input ends cat."""
        if self.proc.stdin and not self.proc.stdin.closed:
            try:
                self.proc.stdin.close()
            except OSError:
                pass
        try:
            self.proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.wait()

    def release_inherited(self) -> None:
        """In a forked copy of the driver: close this copy of the pipe that keeps the holder alive, and never wait
        on or signal the holder, which is not this process's child."""
        for stream in (self.proc.stdin, self.proc.stdout, self.proc.stderr):
            try:
                if stream is not None:
                    stream.close()
            except OSError:
                pass


_holder = None      # this process's holder
_joined = None      # the holder the call now running joined (set by _command), which the check after it uses
_route = {"record": None, "calls": 0, "replacements": [], "trusted": False}


def _reset_route() -> None:
    global _holder
    _holder = None
    _route.update(record=None, calls=0, replacements=[], trusted=False)


def _forget_inherited() -> None:
    """A holder that came through a fork belongs to the parent. This process closes its copy of the pipe, so that the
    parent's holder ends when the parent does, and starts its own holder on its first call."""
    holder = _holder
    if holder is not None and holder.owner != os.getpid():
        try:
            holder.release_inherited()
        finally:
            _reset_route()


if sys.platform == "linux":
    os.register_at_fork(after_in_child=_forget_inherited)


def _keyrings_state() -> str:
    """'absent' if the kernel has no keys, else 'joined'. The probe is an add_key that cannot succeed (keyring number
    0 does not exist), so it adds nothing to any keyring. A kernel without keys answers ENOSYS to it."""
    result = _syscall(key_calls()[0], b"user", b"route-probe", 0, 0, 0)
    return "absent" if result == -errno.ENOSYS else "joined"


def _start_holder(started_by: str) -> Holder:
    """Start a holder, read its socket tables and, for the process's first holder, make the route's record."""
    global _holder, _KEYRINGS_ABSENT
    if sys.platform != "linux" or key_calls() is None:
        raise RouteError(f"there is no Linux route on {sys.platform} / {platform.machine()}")
    if not _linux_available():
        raise RouteError("the Linux route is not available here: " + ", ".join(LINUX_TOOLS)
                         + " must exist and unprivileged user namespaces must be enabled")
    holder = Holder()
    try:
        holder.baseline = _socket_counts(holder.pid)
        if not holder.baseline:
            raise RouteError(f"the holder {holder.pid} has no readable socket table")
        keyrings = _keyrings_state()
    except BaseException:
        holder.close()
        raise
    _KEYRINGS_ABSENT = keyrings == "absent"
    if _route["record"] is None:
        _route["record"] = {"route": LINUX_ROUTE, "holder_pid": holder.pid, "user_ns": holder.user_ns,
                            "net_ns": holder.net_ns, "driver_pid": os.getpid(), "kernel": os.uname().release,
                            "machine": platform.machine(), "keyrings": keyrings, "started_by": started_by,
                            "socket_baseline": dict(holder.baseline)}
    _holder = holder
    return holder


def _ready_holder(started_by: str):
    """This process's holder, started if it has none or only an inherited one, replaced if it is spent, and checked.
    A dead holder is never replaced: that raises."""
    global _holder
    _forget_inherited()
    holder = _holder
    if holder is not None and holder.spent:
        spent = holder.spent
        died = not holder.alive()                # a spent holder that has also died: the record says so
        new = _start_holder(started_by)          # the old one stays until the new one is up
        entry = {"call": spent[0], "status": spent[1], "reason": spent[2], "table": spent[3],
                 "new_holder_pid": new.pid}
        if died:
            entry["holder_died"] = True
        _route["replacements"].append(entry)
        holder.close()
        holder = new
    elif holder is None:
        holder = _start_holder(started_by)
    holder.check()
    return holder


def _mark_spent(status: str, reason: str, table: str | None = None) -> None:
    """The holder's namespace may hold something a stopped call left, so no later call may join it. It is the holder
    the running call joined; before any call has joined one, the process's own."""
    holder = _joined if _joined is not None else _holder
    if holder is not None and not holder.spent:
        holder.spent = (_route["calls"], status, reason, table)


def _after_call(result: SandboxResult) -> None:
    """After a call's process has been waited for and before its result goes back, on Linux: the holder the call
    joined must still be this process's holder, alive and in its namespace, and if the call ended normally its socket
    tables must have the counts they had when the holder was ready, or the holder is marked spent. Whatever raises
    here marks the holder spent first, so that no later call joins a namespace whose tables were not counted."""
    global _joined
    holder, _joined = _joined, None
    if sys.platform != "linux" or holder is None:
        return
    try:
        if _holder is not holder:
            raise RouteError(f"the holder {holder.pid} that the call joined is no longer the route's holder")
        holder.check()
        if not holder.spent:
            counts = _socket_counts(holder.pid)
            gone = sorted(t for t in holder.baseline if t not in counts)
            if gone:
                raise RouteError(f"the socket tables {','.join(gone)} of the holder {holder.pid} cannot be found")
            holder.check()                       # a holder that died during the count shows as missing tables above
            if counts != holder.baseline:
                tables = sorted(t for t in set(counts) | set(holder.baseline) if counts.get(t) != holder.baseline.get(t))
                holder.spent = (_route["calls"], result.status, "residue", ",".join(tables))
    except BaseException:
        if not holder.spent:
            holder.spent = (_route["calls"], result.status, "after-call check failed", None)
        raise


def start_route() -> dict:
    """Start this process's route before anything here makes a call, and return the route's record. On macOS there is
    nothing to start. On Linux it starts the holder if the process has none, makes one trusted call through it and
    raises RouteError unless that returns 'ok'. Called again it returns the same record."""
    if sys.platform == "darwin":
        return {"route": "sandbox-exec"}
    if sys.platform != "linux":
        raise RouteError(f"there is no containment route on {sys.platform}")
    with _ONE_CHILD:
        _ready_holder("start_route")
    if not _route["trusted"]:
        try:
            result = run(TRUSTED_CALL, "decide", None)
        except RouteError:
            end_route()
            raise
        except Exception as error:
            end_route()
            raise RouteError(f"the trusted call could not be made: {type(error).__name__}: {error}") from error
        if result.status != "ok" or result.result != 1:
            end_route()
            raise RouteError(f"the trusted call returned {result.status!r}, {result.result!r}, {result.error!r}")
        _route["trusted"] = True
    return dict(_route["record"])


def route_state() -> dict:
    """The route's record with the number of calls made and every replacement of a holder: each as the stopped
    call's number, its status, the reason ('stopped'; 'residue' with the table; or 'after-call check failed', which
    includes a holder that died during the call), the new holder's number, and holder_died when the spent holder was
    found dead."""
    if sys.platform == "darwin":
        return {"route": "sandbox-exec"}
    if _route["record"] is None:
        raise RouteError("the route has not started in this process")
    return dict(_route["record"], calls=_route["calls"], replacements=[dict(r) for r in _route["replacements"]],
                holder_pid_now=_holder.pid if _holder is not None else None,
                holder_spent=bool(_holder is not None and _holder.spent))


def end_route() -> None:
    """End this process's holder and forget the route."""
    holder = _holder
    _reset_route()
    if holder is not None and holder.owner == os.getpid():
        holder.close()


# The trusted setup run inside the new namespaces, before any model-written code. $1 is the interpreter, $2 the
# privilege drop, $3 the runner source, $4 the interpreter's installation. Every bind is made read-only, then the
# root itself; the process changes root and starts Python with the drop, which then runs the runner.
LINUX_SETUP = r"""set -eu
R=__ROOT__
PY="$1"; DROP="$2"; RUN="$3"; INSTALL="$4"
mount -t tmpfs -o size=1m,mode=0755 telohelm-sandbox "$R"
mount --bind "$R" "$R"
mkdir -p "$R/dev" "$R$INSTALL"
for d in /usr/lib /usr/lib64 "$INSTALL"; do
  [ -d "$d" ] || continue
  mkdir -p "$R$d"
  mount --bind "$d" "$R$d"
  mount -o remount,bind,ro,nosuid,nodev "$R$d"
done
[ -e "$R/lib" ] || ln -s usr/lib "$R/lib"
[ -e "$R/lib64" ] || ln -s usr/lib64 "$R/lib64"
for f in /dev/null /dev/urandom; do
  : > "$R$f"
  mount --bind "$f" "$R$f"
  mount -o remount,bind,ro "$R$f"
done
mount -o remount,bind,ro,nosuid,nodev "$R"
exec chroot "$R" "$PY" -I -S -c "$DROP" "$RUN"
""".replace("__ROOT__", LINUX_ROOT)

# The seccomp filter's program. One function builds it from the numbers the machine refuses and works out every jump,
# so that no jump is written by hand. The text is run here, for the tests and the record, and is also pasted into
# LINUX_DROP, which installs what the function gives. Each instruction is (code, jump if true, jump if false, k) and a
# jump counts from the next instruction. The kernel gives the filter the system call's number at offset 0 and the
# machine code at offset 4. Codes: 0x20 load a word, 0x15 jump if equal, 0x35 jump if greater or equal, 0x06 return.
# The program kills the process when the machine code is not this machine's, fails with EPERM every number in the list
# and, on x86_64, every number with the x32 bit set (x32 calls report the same machine code and have the same numbers
# plus 0x40000000), and allows the rest.
SECCOMP_BUILDER = r'''
MACHINES = __MACHINES__
def seccomp_program(machine):
    audit_arch, x32, refused = MACHINES[machine]
    steps = [(0x20, 0, 0, 4),                      # load the machine code
             (0x15, 1, 0, audit_arch),             # if it is this machine's, skip the next instruction
             (0x06, 0, 0, 0x80000000),             # another machine type: kill the process
             (0x20, 0, 0, 0)]                      # load the system call's number
    refuse_at = len(steps) + (1 if x32 else 0) + len(refused) + 1   # after the comparisons and the allow
    if x32:
        steps.append((0x35, refuse_at - len(steps) - 1, 0, 0x40000000))
    for number in refused:
        steps.append((0x15, refuse_at - len(steps) - 1, 0, number))
    steps.append((0x06, 0, 0, 0x7FFF0000))         # allow
    steps.append((0x06, 0, 0, 0x00050001))         # fail with EPERM
    if len(steps) != refuse_at + 1 or any(not 0 <= step[1] <= 255 for step in steps):
        raise ValueError("the seccomp program's jumps do not fit")
    return steps
'''.replace("__MACHINES__", repr({m: (KEY_CALLS[m][3], m == "x86_64", KEY_CALLS[m][:3] + NAMESPACE_CALLS[m])
                                    for m in KEY_CALLS}))
_builder_names: dict = {}
exec(SECCOMP_BUILDER, _builder_names)
seccomp_program = _builder_names["seccomp_program"]
del _builder_names


# The first lines Python runs inside the root, while it is still root in the namespace. The order matters: dropping
# from the bounding set and setting securebits need CAP_SETPCAP, so the capabilities themselves go last. Then the
# capabilities are read back and must all be zero. The runner's source is the one argument; it runs as __main__.
LINUX_DROP = r"""
import ctypes, os, resource, sys
libc = ctypes.CDLL(None, use_errno=True)
libc.prctl.argtypes = [ctypes.c_int] + [ctypes.c_ulong] * 4
libc.syscall.restype = ctypes.c_long
def check(ok, what):
    if not ok:
        sys.stderr.write("privilege drop failed: %s (errno %d)\n" % (what, ctypes.get_errno()))
        sys.stderr.flush()
        import os; os._exit(97)
def sc(number, *args):
    return libc.syscall(ctypes.c_long(number), *[ctypes.c_char_p(a) if isinstance(a, bytes) else ctypes.c_long(a) for a in args])
ADD_KEY, REQUEST_KEY, KEYCTL, AUDIT_ARCH = __KEY_CALLS__.get(os.uname().machine, (None,) * 4)
__SECCOMP_BUILDER__
check(KEYCTL is not None, "machine type")
# The parent joined this process to a new session keyring before it started. It must be empty: keyctl(KEYCTL_READ = 11,
# KEY_SPEC_SESSION_KEYRING = -3, NULL, 0) gives the length of its list of keys. On a kernel without keys it fails with
# ENOSYS, and then add_key must fail with ENOSYS too (it cannot succeed: keyring 0 does not exist, so it adds nothing).
if sc(KEYCTL, 11, -3, 0, 0) < 0 and ctypes.get_errno() == 38:
    check(sc(ADD_KEY, b"user", b"x", 0, 0, 0) == -1 and ctypes.get_errno() == 38, "keys are absent but add_key works")
else:
    check(sc(KEYCTL, 11, -3, 0, 0) == 0, "session keyring is not empty")
cap = 0
while libc.prctl(24, cap, 0, 0, 0) == 0:                 # PR_CAPBSET_DROP, until the number is past the last one
    cap += 1
check(ctypes.get_errno() == 22 and cap >= 38, "bounding set")
check(libc.prctl(47, 4, 0, 0, 0) == 0, "ambient set")     # PR_CAP_AMBIENT, PR_CAP_AMBIENT_CLEAR_ALL
check(libc.prctl(28, 0xEF, 0, 0, 0) == 0, "securebits")   # PR_SET_SECUREBITS: noroot, no setuid fixup, keep caps off,
                                                           # no ambient raise, each locked
class Header(ctypes.Structure):
    _fields_ = [("version", ctypes.c_uint32), ("pid", ctypes.c_int)]
Data = (ctypes.c_uint32 * 3) * 2                           # effective, permitted, inheritable; two 32-bit halves
check(libc.capset(ctypes.byref(Header(0x20080522, 0)), ctypes.byref(Data())) == 0, "capset")
held = Data()
check(libc.capget(ctypes.byref(Header(0x20080522, 0)), ctypes.byref(held)) == 0, "capget")
check(not any(v for half in held for v in half), "capabilities still held")
check(libc.prctl(38, 1, 0, 0, 0) == 0, "no new privileges")   # PR_SET_NO_NEW_PRIVS
# A seccomp filter that makes add_key, request_key, keyctl, socket, socketpair and io_uring_setup fail with EPERM, so
# that the runner cannot even test a guessed key number and cannot create anything in the network namespace that the
# calls after it share. seccomp_program (defined above, in SECCOMP_BUILDER) gives the instructions.
class Insn(ctypes.Structure):
    _fields_ = [("code", ctypes.c_uint16), ("jt", ctypes.c_uint8), ("jf", ctypes.c_uint8), ("k", ctypes.c_uint32)]
class Prog(ctypes.Structure):
    _fields_ = [("len", ctypes.c_uint16), ("filter", ctypes.POINTER(Insn))]
steps = seccomp_program(os.uname().machine)
prog = Prog(len(steps), (Insn * len(steps))(*steps))
check(libc.prctl(22, 2, ctypes.addressof(prog), 0, 0) == 0, "seccomp filter")   # PR_SET_SECCOMP, SECCOMP_MODE_FILTER
check(sc(KEYCTL, 0, -3, 0) == -1 and ctypes.get_errno() == 1, "key calls are still allowed")   # KEYCTL_GET_KEYRING_ID
resource.setrlimit(resource.RLIMIT_NPROC, (1, 1))
source = sys.argv.pop(1)
del libc, check, sc, cap, held, Header, Data, ADD_KEY, REQUEST_KEY, KEYCTL, AUDIT_ARCH, Insn, Prog, steps, prog, MACHINES, seccomp_program
exec(compile(source, "<runner>", "exec"), {"__name__": "__main__", "__builtins__": __builtins__})
""".replace("__KEY_CALLS__", repr(KEY_CALLS)).replace("__SECCOMP_BUILDER__", SECCOMP_BUILDER)


def _command(python: Path, runner: str) -> list[str]:
    """The command that runs the runner in the contained process on this platform."""
    if sys.platform == "darwin":
        return ["sandbox-exec", "-p", profile(python), str(python), "-I", "-S", "-c", runner]
    global _joined
    _joined = None
    holder = _ready_holder("first call")
    _joined = holder                           # the check after the call looks at this object, not at _holder
    _route["calls"] += 1
    install = str(python.parents[1])           # .../cpython-3.12.x/ holds bin/ and lib/
    return [word.format(holder=holder.pid) for word in JOIN_WORDS] + CALL_NAMESPACES + [
        "sh", "-c", LINUX_SETUP, "sh", str(python), LINUX_DROP, runner, install]


_ONE_CHILD = threading.Lock()


def run(code: str, entry: str, payload: Any, wall_seconds: float = WALL_SECONDS,
        context_args: bool = False) -> SandboxResult:
    """Calls through this function are serialised. The CPU figure is the difference in the process's completed-
    children usage around one call, so it belongs to that call's child only if no other child process of this
    parent finishes meanwhile. That exclusive-child condition is assumed, not enforced, for any other subprocess
    (Codex's TURN 26 note). The recorded wall time starts after any wait for the lock."""
    with _ONE_CHILD:
        result = _run(code, entry, payload, wall_seconds, context_args)
        _after_call(result)
        return result


def _run(code: str, entry: str, payload: Any, wall_seconds: float, context_args: bool) -> SandboxResult:
    """Run entry(payload) from code in a contained process and return its JSON result.

    With context_args, payload is a list of records, each passed as a read-only attribute-only context
    object (backlog note B7), so that decide(ctx) or check(ctx, out) can be called."""
    if not available():
        raise SandboxUnavailable(f"no tested containment route on {sys.platform}")
    python = interpreter()
    # Every call, live or replay, sends a message of exactly this form, so the running code cannot tell a
    # test from real work by anything the runner holds (Codex's R22.2 read the runner's frame; batch mode,
    # which a replay used, is removed for that reason).
    message = json.dumps({"code": code, "entry": entry, "input": payload, "wrap": context_args}, allow_nan=False)
    command = _command(python, RUNNER)
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    start = time.perf_counter()
    deadline = start + wall_seconds
    proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                            env={}, cwd="/", close_fds=True, preexec_fn=_limits)
    try:
        memory: dict = {}
        if sys.platform == "darwin":           # on Linux the address-space limit holds memory inside the process
            watcher = threading.Thread(target=_watch_memory, args=(proc, MEMORY_LIMIT_MB, memory), daemon=True)
            watcher.start()

        def cpu_used() -> float:
            after = resource.getrusage(resource.RUSAGE_CHILDREN)
            return (after.ru_utime - before.ru_utime) + (after.ru_stime - before.ru_stime)

        def stop(status: str, error: str) -> SandboxResult:
            _mark_spent(status, "stopped")
            if proc.poll() is None:
                proc.kill()
            proc.wait()
            return SandboxResult(status, error=error, wall_seconds=time.perf_counter() - start, cpu_seconds=cpu_used())

        # Write the message and read the reply with non-blocking pipes under one deadline, in bounded chunks, so that
        # neither a slow child, a blocked write nor a large or slow reply can hold the parent past the deadline or fill
        # its memory (Codex's R22.4, R22.8 and R24.IO: a blocking write before the read loop could overrun).
        pending = message.encode()
        out_fd, in_fd = proc.stdout.fileno(), proc.stdin.fileno()
        os.set_blocking(in_fd, False)
        os.set_blocking(out_fd, False)
        writing = True
        chunks, size = [], 0
        while True:
            remaining = deadline - time.perf_counter()
            if remaining <= 0:
                return stop("timeout", "wall-clock limit")
            readable, writable, _ = select.select([out_fd], [in_fd] if writing else [], [], remaining)
            if writable:
                try:
                    sent = os.write(in_fd, pending[:65536])
                    pending = pending[sent:]
                except BlockingIOError:
                    pass
                except BrokenPipeError:
                    writing = False
                    proc.stdin.close()
                if writing and not pending:
                    writing = False
                    proc.stdin.close()
            if readable:
                try:
                    chunk = os.read(out_fd, 65536)
                except BlockingIOError:
                    continue
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_REPLY_BYTES:
                    return stop("bad_reply", "reply too large")
                chunks.append(chunk)
        try:
            proc.wait(timeout=max(0.0, deadline - time.perf_counter()))
        except subprocess.TimeoutExpired:
            return stop("timeout", "wall-clock limit after output")
        out = b"".join(chunks)
        wall = time.perf_counter() - start
        cpu = cpu_used()
        # No join: the watcher sleeps between readings, and waiting for it added about 25 ms to every call.
        # It sets the flag before it kills the child, so the flag is already set if memory was the cause.
        if memory.get("exceeded"):
            return SandboxResult("memory", error=f"resident memory above {MEMORY_LIMIT_MB} MB", wall_seconds=wall,
                                 cpu_seconds=cpu)
        if proc.returncode != 0:
            status = "timeout" if proc.returncode in (-24, -9) else "crashed"   # SIGXCPU or kill at the CPU limit
            return SandboxResult(status, error=f"exit {proc.returncode}", wall_seconds=wall, cpu_seconds=cpu)
        if len(out) > MAX_REPLY_BYTES:
            return SandboxResult("bad_reply", error="reply too large", wall_seconds=wall, cpu_seconds=cpu,
                                 reply_bytes=len(out))
        try:
            reply = json.loads(out)
        except ValueError:
            return SandboxResult("bad_reply", error="reply is not JSON", wall_seconds=wall, cpu_seconds=cpu,
                                 reply_bytes=len(out))
        if reply.get("ok"):
            return SandboxResult("ok", result=reply["result"], wall_seconds=wall, cpu_seconds=cpu, reply_bytes=len(out))
        if _out_of_memory(reply.get("error")):
            return SandboxResult("memory", error=reply.get("error"), wall_seconds=wall, cpu_seconds=cpu, reply_bytes=len(out))
        return SandboxResult("error", error=reply.get("error"), wall_seconds=wall, cpu_seconds=cpu, reply_bytes=len(out))
    except BaseException:
        _mark_spent("interrupted", "stopped")
        if proc.poll() is None:
            proc.kill()
        proc.wait()
        raise


def _out_of_memory(error: Any) -> bool:
    """On Linux the address-space limit turns an oversized allocation into MemoryError inside the process."""
    return sys.platform == "linux" and isinstance(error, str) and error.startswith("MemoryError")


def _final_envelope(body: bytes) -> dict | None:
    """The final frame must be exactly {"ok": true, "result": <finite JSON>} or {"ok": false, "error": <text>}, with
    no other keys, no repeated keys and no NaN or infinity; anything else is refused (Codex's BR57.FINAL)."""
    def no_constant(name):
        raise ValueError(name)

    def unique(pairs):
        if len({k for k, _ in pairs}) != len(pairs):
            raise ValueError("duplicate key")
        return dict(pairs)
    try:
        reply = json.loads(body, parse_constant=no_constant, object_pairs_hook=unique)
    except (ValueError, RecursionError):
        return None
    if not isinstance(reply, dict) or not isinstance(reply.get("ok"), bool):
        return None
    if reply["ok"] is True and set(reply) == {"ok", "result"}:
        try:
            json.dumps(reply["result"], allow_nan=False)
        except (ValueError, OverflowError):
            return None
        return reply
    if reply["ok"] is False and set(reply) == {"ok", "error"} and isinstance(reply["error"], str):
        return reply
    return None


def run_with_broker(code: str, entry: str, payload: Any, broker: Any, purpose: str,
                    wall_seconds: float = WALL_SECONDS, context_args: bool = False) -> SandboxResult:
    """Like run(), with a broker channel: the procedure may call predict(args), which reaches the broker as one
    request and returns its reply. The broker call is opened and closed here, with the sandbox's outcome as its
    status. One deadline covers the whole exchange: writing the call, every request and reply, the broker's own
    work and the child's exit. The trusted tool is not pre-empted; if it overruns, the deadline is found when it
    returns. Calls are serialised with run()."""
    with _ONE_CHILD:
        call = broker.open_call(purpose)
        try:
            result = _run_channel(code, entry, payload, call, wall_seconds, context_args)
            _after_call(result)
        except BaseException as exc:
            broker.close_call(call, "interrupted", f"{type(exc).__name__}: {exc}")
            raise
        broker.close_call(call, {"ok": "completed"}.get(result.status, result.status), result.error)
        return result


def _run_channel(code: str, entry: str, payload: Any, call: Any, wall_seconds: float,
                 context_args: bool) -> SandboxResult:
    from .broker import MAX_MESSAGE_BYTES; from .broker import MAX_REPLY_BYTES as BROKER_REPLY_BYTES
    if not available():
        raise SandboxUnavailable(f"no tested containment route on {sys.platform}")
    python = interpreter()
    message = json.dumps({"code": code, "entry": entry, "input": payload, "wrap": context_args}, allow_nan=False)
    command = _command(python, RUNNER_BROKER)
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    start = time.perf_counter()
    deadline = start + wall_seconds
    proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                            env={}, cwd="/", close_fds=True, preexec_fn=_limits)
    try:
        memory: dict = {}
        if sys.platform == "darwin":           # on Linux the address-space limit holds memory inside the process
            watcher = threading.Thread(target=_watch_memory, args=(proc, MEMORY_LIMIT_MB, memory), daemon=True)
            watcher.start()
        requests = 0

        def frame(kind: bytes, body: bytes) -> bytes:
            return kind + b"%010d" % len(body) + body

        def cpu_used() -> float:
            after = resource.getrusage(resource.RUSAGE_CHILDREN)
            return (after.ru_utime - before.ru_utime) + (after.ru_stime - before.ru_stime)

        def stop(status: str, error: str) -> SandboxResult:
            _mark_spent(status, "stopped")
            if proc.poll() is None:
                proc.kill()
            proc.wait()
            return SandboxResult(status, error=error, wall_seconds=time.perf_counter() - start, cpu_seconds=cpu_used(),
                                 broker_requests=requests)

        pending = frame(b"M", message.encode())
        out_fd, in_fd = proc.stdout.fileno(), proc.stdin.fileno()
        os.set_blocking(in_fd, False)
        os.set_blocking(out_fd, False)
        buf = b""
        final = None
        while final is None:
            remaining = deadline - time.perf_counter()
            if remaining <= 0:
                return stop("timeout", "wall-clock limit")
            readable, writable, _ = select.select([out_fd], [in_fd] if pending else [], [], remaining)
            if writable and pending:
                try:
                    pending = pending[os.write(in_fd, pending[:65536]):]
                except BlockingIOError:
                    pass
                except BrokenPipeError:
                    pending = b""
            if readable:
                try:
                    chunk = os.read(out_fd, 65536)
                except BlockingIOError:
                    continue
                if not chunk:
                    break
                buf += chunk
            while len(buf) >= FRAME_HEAD and final is None:
                kind, digits = buf[:1], buf[1:FRAME_HEAD]
                if kind not in (b"R", b"F") or not digits.isdigit():
                    return stop("bad_reply", "protocol violation on the broker channel")
                n = int(digits)
                if n > (MAX_MESSAGE_BYTES if kind == b"R" else MAX_REPLY_BYTES):
                    return stop("bad_reply", "frame too large")
                if len(buf) < FRAME_HEAD + n:
                    break
                body, buf = buf[FRAME_HEAD:FRAME_HEAD + n], buf[FRAME_HEAD + n:]
                if kind == b"F":
                    final = body
                    break
                requests += 1
                reply = call.request(body.decode("utf-8", "surrogateescape")).encode()
                if len(reply) > BROKER_REPLY_BYTES:          # the broker refuses first; this is a second guard
                    return stop("bad_reply", "broker reply over the channel bound")
                pending += frame(b"A", reply)
                if time.perf_counter() > deadline:
                    return stop("timeout", "wall-clock limit during a broker request")
        if final is None:
            if proc.poll() is None:
                try:
                    proc.wait(timeout=max(0.0, deadline - time.perf_counter()))
                except subprocess.TimeoutExpired:      # output closed but the child lives on (Codex's BR57.EOF)
                    return stop("timeout", "output closed without a final frame; wall-clock limit")
            wall, cpu = time.perf_counter() - start, cpu_used()
            if memory.get("exceeded"):
                return SandboxResult("memory", error=f"resident memory above {MEMORY_LIMIT_MB} MB", wall_seconds=wall,
                                     cpu_seconds=cpu, broker_requests=requests)
            status = "timeout" if proc.returncode in (-24, -9) else "crashed"
            return SandboxResult(status, error=f"no final frame; exit {proc.returncode}", wall_seconds=wall,
                                 cpu_seconds=cpu, broker_requests=requests)
        if buf:
            return stop("bad_reply", "bytes after the final frame")
        # Read on to end of file under the same deadline, so bytes written after the final frame, even late, are
        # found (Codex's BR57.DRAIN).
        while True:
            remaining = deadline - time.perf_counter()
            if remaining <= 0:
                return stop("timeout", "wall-clock limit after the final frame")
            readable, _, _ = select.select([out_fd], [], [], remaining)
            if not readable:
                continue
            try:
                chunk = os.read(out_fd, 65536)
            except BlockingIOError:
                continue
            if not chunk:
                break
            return stop("bad_reply", "bytes after the final frame")
        try:
            proc.wait(timeout=max(0.0, deadline - time.perf_counter()))
        except subprocess.TimeoutExpired:
            return stop("timeout", "wall-clock limit after output")
        wall, cpu = time.perf_counter() - start, cpu_used()
        if memory.get("exceeded"):
            return SandboxResult("memory", error=f"resident memory above {MEMORY_LIMIT_MB} MB", wall_seconds=wall,
                                 cpu_seconds=cpu, broker_requests=requests)
        if proc.returncode != 0:
            return SandboxResult("crashed", error=f"exit {proc.returncode}", wall_seconds=wall, cpu_seconds=cpu,
                                 broker_requests=requests)
        reply = _final_envelope(final)
        if reply is None:
            return SandboxResult("bad_reply", error="final frame is not a valid envelope", wall_seconds=wall,
                                 cpu_seconds=cpu, reply_bytes=len(final), broker_requests=requests)
        if reply["ok"]:
            return SandboxResult("ok", result=reply["result"], wall_seconds=wall, cpu_seconds=cpu,
                                 reply_bytes=len(final), broker_requests=requests)
        status = "memory" if _out_of_memory(reply["error"]) else "error"
        return SandboxResult(status, error=reply["error"], wall_seconds=wall, cpu_seconds=cpu,
                             reply_bytes=len(final), broker_requests=requests)
    except BaseException:
        _mark_spent("interrupted", "stopped")
        if proc.poll() is None:
            proc.kill()
        proc.wait()
        raise

